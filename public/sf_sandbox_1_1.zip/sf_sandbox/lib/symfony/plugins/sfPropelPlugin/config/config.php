<?php

set_include_path(realpath(dirname(__FILE__).'/../lib/vendor').PATH_SEPARATOR.sfConfig::get('sf_root_dir').PATH_SEPARATOR.get_include_path());
