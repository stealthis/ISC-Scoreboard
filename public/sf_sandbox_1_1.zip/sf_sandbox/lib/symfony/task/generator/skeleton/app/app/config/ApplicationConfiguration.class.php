<?php

class ##APP_NAME##Configuration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
